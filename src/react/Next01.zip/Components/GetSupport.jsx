import React from 'react'

const GetSupport = () => {
  return (
    <div>
        <div class="shadow">welcome</div>
    </div>
  )
}

export default GetSupport
